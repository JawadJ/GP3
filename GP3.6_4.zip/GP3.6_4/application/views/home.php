<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
		h1 { text-align: center; 	font-family: Calibri; }
		p.p-centre { text-align: center; font-family: Arial; }
		#Stefan { display: block; padding-top: 20px; margin-left: auto; margin-right: auto; }		
	</style>
</head>
<body>
<h1>Delivery Access Management for Invictus Games Events - DAMIGE</h1>
<div align="center">
	<img id="invictus" src="assets/images/invictus.png" alt="inv" height="204" width="404">
	<!--Image credits: https://invictusgamesfoundation.org/wp-content/uploads/2016/10/invictus_games_foundation_logo.png -->
</div>



<p class="p-centre"><b>GP3 Group 6_4</b></p>
<p class="p-centre"><i>Stefan Cooper 15033114</i></p>
<p class="p-centre"><i>Jawad Jamil 15037070</i></p>
<p class="p-centre"><i>Hassan Mughal 15034328</i></p>
<p class="p-centre"><i>Shurf Uddin 15034558</i></p>
<p class="p-centre"><i>Leon Oram 15030640</i></p>


</body>
</html>
