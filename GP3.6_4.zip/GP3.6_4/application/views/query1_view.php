<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
		h1, h2 { text-align: center; font-family: Calibri; }
		table.mytable {border-collapse: collapse;}
		table.mytable td, th {border: 1px solid grey; padding: 5px 15px 2px 7px;}
		th {background-color: #f2e4d5;}		
	</style>
</head>
<body>

<h1>Queries</h1>
<div align='center'>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query1')?>'">Total Deliveries to each Venue</button>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query2')?>'">Total Current Employees per Company</button>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query3')?>'">Total Current Employees per Company</button>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query4')?>'">Deliveries per Driver</button>
</div>
<h2>Total Deliveries to each Venue</h2>
<div align='center'>
<?php
	$tmpl = array ('table_open' => '<table class="mytable">');
	$this->table->set_template($tmpl); 
	
	$this->db->query('drop table if exists temp');
	//$this->db->query("create temporary table temp as (SELECT DeliveryVenue, COUNT(*)FROM deliveryWHERE Status='Delivered')");
	$this->db->query("create temporary table temp as (select delivery.Status,VenueStadiumName, DeliveryDate AS 'Venue Stadium Name',COUNT(*) AS 'Total Deliveries'
	from delivery, venue 
	where venue.VenueID= delivery.DeliveryVenue AND DeliveryDate='20/10/2018'
	group by delivery.DeliveryVenue)");
	$query = $this->db->query('SELECT * from temp;');
	echo $this->table->generate($query);
?>
</div>
</body>
</html>
