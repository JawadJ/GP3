<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
		h1 {text-align: center; font-family: Calibri;}
	</style>
</head>
<body>

<h1>Queries</h1>
<div align='center'>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query1')?>'">Total Deliveries to each Venue</button>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query2')?>'">Total Current Employees per Company</button>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query3')?>'">Total Vehicles per Company</button>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query4')?>'">Deliveries per Driver</button>
</div>
    
</body>
</html>
