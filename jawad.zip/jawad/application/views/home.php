<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
		h1 { text-align: center; 	font-family: Calibri; }
		p.p-centre { text-align: center; font-family: Arial; }
		#cogs { display: block; padding-top: 20px; margin-left: auto; margin-right: auto; }		
	</style>
</head>
<body>

<h1>GP3 Jawad Dumb Cyka</h1>

<p class="p-centre">Ez gp3 assignment</p>
<p class="p-centre">Best gp3 ever</p>

<div align="center">
	<img id="jawadpic" src="assets/images/jawad.png" alt="jawadpiclol" height="700" width="1920">
	<!--Image credits: http://www.wallpaperdecor.com.au/murals/scandinavian-wallpaper-decor/typography-collection/cogs-gears-e21324/ -->
</div>
</body>
</html>
