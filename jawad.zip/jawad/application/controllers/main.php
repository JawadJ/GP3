<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {
	 
	 function __construct()
	{
		parent::__construct();	 
		$this->load->database();
		$this->load->helper('url');
		$this->load->library('grocery_CRUD');
		$this->load->library('table');
	}
	
	public function index()
	{	
		$this->load->view('header');
		$this->load->view('home');
	}
	

	
	public function querynav()
	{	
		$this->load->view('header');
		$this->load->view('querynav_view');
	}
		
	public function query1()
	{	
		$this->load->view('header');
		$this->load->view('query1_view');
	}
	
	public function query2()
	{	
		$this->load->view('header');
		$this->load->view('query2_view');
	}
	
	public function blank()
	{	
		$this->load->view('header');
		$this->load->view('blank_view');
	}
	
	public function Vehicle()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		
		$crud->set_table('vehicle');
		$crud->set_subject('Vehicle');
		$crud->columns('VehicleReg', 'VehicleBrand', 'VehicleModel', 'VehicleSupplierID');
		$crud->fields('VehicleReg', 'VehicleBrand', 'VehicleModel', 'VehicleSupplierID');
		$crud->required_fields('VehicleReg', 'VehicleBrand', 'VehicleModel', 'VehicleSupplierID');
		//$crud->set_relation('Vehicle Registration','vehicle','Vehicle Registration');
		//$crud->display_as('', 'Vehicle Registration','Vehicle Brand', 'Vehicle Model', 'Vehicle Supplier ID');
		
		$crud->set_relation('VehicleSupplierID','supplier','SupplierID');
		
		$crud->display_as('VehicleReg', 'Reg');
		$crud->display_as('VehicleBrand', 'Brand');
		$crud->display_as('VehicleModel', 'Model');
		$crud->display_as('VehicleSupplier ID', 'Supplier ID');
		//$crud->display_as('custPostcode', 'Postcode')
		
		$output = $crud->render();
		$this->Vehicle_output($output);
	}
	
	function Vehicle_output($output = null)
	{
		$this->load->view('vehicle_view.php', $output);
	}
	
	public function venue()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('venue');
		$crud->set_subject('Venue');
		$crud->columns('VenueID', 'VenueStadiumName', 'VenueArea', 'VenueContactNo', 'VenueAddress');
		$crud->display_as('VenueID', 'Venue ID');
		$crud->display_as('VenueStadium Name', 'Venue Stadium Name');
		$crud->display_as('VenueArea', 'Venue Area');
		$crud->display_as('VenueContact No.', 'Venue Contact No.');
		$crud->display_as('VenueAddress', 'Venue Address');

		$crud->fields('VenueID', 'VenueStadiumName', 'VenueArea', 'VenueContactNo.', 'VenueAddress');
		$crud->required_fields('VenueID', 'VenueStadiumName', 'VenueArea', 'VenueAddress');

		
		$output = $crud->render();
		$this->Venue_output($output);
	}

	function Venue_output($output = null)
	{
		$this->load->view('venue_view.php', $output);
	}
	
	public function delivery()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('delivery');
		$crud->set_subject('Delivery');
		$crud->columns('DeliveryID', 'DeliveryDate', 'DeliveryVehicleReg', 'DeliveryVenueID', 'DeliverySupplierID','DeliveryDriverID');
		$crud->set_relation('DeliveryVehicleReg','vehicle','VehicleReg');
		$crud->set_relation('DeliveryVenueID','venue','VenueID');
		$crud->set_relation('DeliverySupplierID','supplier','SupplierID');
		$crud->set_relation('DeliveryDriverID','driver','DriverID');
	/*	$crud->display_as('VenueID', 'Venue ID');
		$crud->display_as('VenueStadium Name', 'Venue Stadium Name');
		$crud->display_as('VenueArea', 'Venue Area');
		$crud->display_as('VenueContact No.', 'Venue Contact No.');
		$crud->display_as('VenueAddress', 'Venue Address');*/

		$crud->fields('DeliveryID', 'DeliveryDate', 'DeliveryVehicleReg', 'DeliveryVenueID', 'DeliverySupplierID','DeliveryDriverID');
		$crud->required_fields('DeliveryID', 'DeliveryDate', 'DeliveryVehicleReg', 'DeliveryVenueID', 'DeliverySupplierID','DeliveryDriverID');

		
		$output = $crud->render();
		$this->Delivery_output($output);
	}

	function Delivery_output($output = null)
	{
		$this->load->view('delivery_view.php', $output);
	}
	
	public function driver()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('driver','driveridcard');
		$crud->set_subject('Driver');
		$crud->columns('DriverID', 'DriverEmployer', 'DriverName', 'DriverTitle');
		$crud->set_relation('DriverEmployer','supplier','SupplierName');
		/*$crud->display_as('VenueID', 'Venue ID');
		$crud->display_as('VenueStadium Name', 'Venue Stadium Name');
		$crud->display_as('VenueArea', 'Venue Area');
		$crud->display_as('VenueContact No.', 'Venue Contact No.');
		$crud->display_as('VenueAddress', 'Venue Address');*/

		$crud->fields('DriverID', 'DriverEmployer', 'DriverName', 'DriverTitle','StartDate','EndDate');
		$crud->required_fields('DriverID', 'DriverEmployer', 'DriverName','StartDate','EndDate');
		//$this->db->query("UPDATE driveridcard SET cardid=cardid+1");

		
		$output = $crud->render();
		$this->Driver_output($output);
	}

	function Driver_output($output = null)
	{
		
		$this->load->view('driver_view.php', $output);
	}
	
	public function driveridcard()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('driveridcard');
		$crud->set_subject('Driver ID Card');
		$crud->columns('CardID', 'Driver', 'StartDate', 'EndDate', 'State');
		/*$crud->display_as('VenueID', 'Venue ID');
		$crud->display_as('VenueStadium Name', 'Venue Stadium Name');
		$crud->display_as('VenueArea', 'Venue Area');
		$crud->display_as('VenueContact No.', 'Venue Contact No.');
		$crud->display_as('VenueAddress', 'Venue Address');*/
		
		
		$crud->set_relation('Driver','driver','DriverID',array('State'=>'Valid'));
		$crud->set_relation('Driver','driver','DriverID');
		$crud->fields('CardID', 'Driver', 'StartDate', 'EndDate');
		$crud->required_fields('CardID', 'Driver', 'StartDate', 'EndDate');

		
		$output = $crud->render();
		$this->Driveridcard_output($output);
	}

	function Driveridcard_output($output = null)
	{
		$this->load->view('driveridcard_view.php', $output);
	}
	
	public function supplier()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('supplier');
		$crud->set_subject('Supplier');
		$crud->columns('SupplierID', 'SupplierName', 'SupplierGaS', 'SupplierAddress', 'SupplierManager');
		$crud->display_as('SupplierID','Supplier ID');
		$crud->display_as('SupplierName','Supplier Name');
		$crud->display_as('SupplierGaS', 'Supplier Goods and Services');
		$crud->display_as('SupplierAddress', 'Supplier Address');
		$crud->display_as('SupplierManager', 'Supplier Manager');

		$crud->fields('SupplierID', 'SupplierName', 'SupplierGaS', 'SupplierAddress', 'SupplierManager');
		$crud->required_fields('SupplierID', 'SupplierName', 'SupplierGaS', 'SupplierAddress', 'SupplierManager');

		
		$output = $crud->render();
		$this->Supplier_output($output);
	}

	function Supplier_output($output = null)
	{
		$this->load->view('supplier_view.php', $output);
	}
	
}
