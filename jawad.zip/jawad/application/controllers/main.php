<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {
	 
	 function __construct()
	{
		parent::__construct();	 
		$this->load->database();
		$this->load->helper('url');
		$this->load->library('grocery_CRUD');
		$this->load->library('table');
	}
	
	public function index()
	{	
		$this->load->view('header');
		$this->load->view('home');
	}
	

	
	public function querynav()
	{	
		$this->load->view('header');
		$this->load->view('querynav_view');
	}
		
	public function query1()
	{	
		$this->load->view('header');
		$this->load->view('query1_view');
	}
	
	public function query2()
	{	
		$this->load->view('header');
		$this->load->view('query2_view');
	}
	
	public function blank()
	{	
		$this->load->view('header');
		$this->load->view('blank_view');
	}
	
	public function Vehicle()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		
		$crud->set_table('vehicle');
		$crud->set_subject('Vehicle');
		$crud->columns('VehicleReg', 'VehicleBrand', 'VehicleModel', 'VehicleSupplier');
		$crud->fields('VehicleReg', 'VehicleBrand', 'VehicleModel', 'VehicleSupplier');
		$crud->required_fields('VehicleReg', 'VehicleBrand', 'VehicleModel', 'VehicleSupplier');
		//$crud->set_relation('Vehicle Registration','vehicle','Vehicle Registration');
		//$crud->display_as('', 'Vehicle Registration','Vehicle Brand', 'Vehicle Model', 'Vehicle Supplier ID');
		
		$crud->set_relation('VehicleSupplier','supplier','SupplierName');
		
		$crud->display_as('VehicleReg', 'Reg');
		$crud->display_as('VehicleBrand', 'Brand');
		$crud->display_as('VehicleModel', 'Model');
		$crud->display_as('VehicleSupplier', 'Vehicle Supplier');
		//$crud->display_as('custPostcode', 'Postcode')
		
		$output = $crud->render();
		$this->Vehicle_output($output);
	}
	
	function Vehicle_output($output = null)
	{
		$this->load->view('vehicle_view.php', $output);
	}
	
	public function venue()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('venue');
		$crud->set_subject('Venue');
		$crud->columns('VenueStadiumName', 'VenueArea', 'VenueContactNo', 'VenueAddress');
		$crud->display_as('VenueStadiumName', 'Venue Stadium Name');
		$crud->display_as('VenueArea', 'Venue Area');
		$crud->display_as('VenueContactNo', 'Venue Contact Number');
		$crud->display_as('VenueAddress', 'Venue Address');

		$crud->fields('VenueStadiumName', 'VenueArea', 'VenueContactNo.', 'VenueAddress');
		$crud->required_fields('VenueStadiumName', 'VenueArea', 'VenueAddress');

		
		$output = $crud->render();
		$this->Venue_output($output);
	}

	function Venue_output($output = null)
	{
		$this->load->view('venue_view.php', $output);
	}
	
	public function delivery()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('delivery');
		$crud->set_subject('Delivery');
		$crud->columns('DeliveryID', 'DeliveryDate', 'DeliveryVehicleReg', 'DeliveryVenue', 'DeliverySupplier','DeliveryDriver');
		$crud->set_relation('DeliveryVehicleReg','vehicle','VehicleReg');
		$crud->set_relation('DeliveryVenue','venue','VenueStadiumName');
		$crud->set_relation('DeliverySupplier','supplier','SupplierName');
		$crud->set_relation('DeliveryDriver','driver','DriverName');
		$crud->display_as('DeliveryVenue', 'Delivery Venue');
		$crud->display_as('DeliverySupplier', 'Delivery Supplier');
		$crud->display_as('DeliveryDriver', 'Delivery Driver');
		$crud->display_as('DeliveryVehicleReg', 'Delivery Vehicle Registration');
		$crud->display_as('DeliveryID', 'Delivery ID');
		$crud->display_as('DeliveryDate', 'Delivery Date');

		$crud->fields('DeliveryDate', 'DeliveryVehicleReg', 'DeliveryVenue', 'DeliverySupplier','DeliveryDriver');
		$crud->required_fields('DeliveryDate', 'DeliveryVehicleReg', 'DeliveryVenue', 'DeliverySupplier','DeliveryDriver');

		
		$output = $crud->render();
		$this->Delivery_output($output);
	}

	function Delivery_output($output = null)
	{
		$this->load->view('delivery_view.php', $output);
	}
	
	public function driver()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('driver');
		$crud->set_subject('Driver');
		$crud->columns('DriverName','DriverEmployer', 'DriverTitle');
	//	$crud->set_relation_n_n('DriverEmployer','driver','supplier','SupplierID','DriverID','SupplierName');
		//$crud->set_relation('DriverEmployer','supplier','SupplierName');
		$crud->set_relation('DriverEmployer','supplier','SupplierName');
		//$crud->set_relation('DriverEmployerID','supplier','SupplierID');
		//$crud->display_as('DriverEmployer', 'Driver Employer');
		$crud->display_as('DriverName', 'Driver Name');
		$crud->display_as('DriverTitle', 'Driver Title');

		$crud->fields('DriverEmployer', 'DriverName', 'DriverTitle');//,'StartDate','EndDate');
		$crud->required_fields('DriverEmployer', 'DriverName');//,'StartDate','EndDate');
		$crud->callback_after_insert(array($this, 'add_driveridcard'));
		//$this->db->query("UPDATE driveridcard SET cardid=cardid+12, cardid=cardid+1");
		/*$crud->callback_add_field('State', function() {
			return '<input type="text" maxlength="60" value="Valid" name="State">';
			});*/
		
		$output = $crud->render();
		$this->Driver_output($output);
	}

	function add_driveridcard($post_array,$primary_key) {
		$driveridcard_insert = array(
		"CardID"=>$primary_key,
		"Driver"=>$post_array['DriverName'],
		"StartDate"=>date('Y-m-d H:i:s'),
		"EndDate"=>date('Y-m-d', strtotime( '+'.(1).' years'))
		);
		$this->db->insert('driveridcard',$driveridcard_insert);
		return true;
	}
	
	function Driver_output($output = null)
	{
		
		$this->load->view('driver_view.php', $output);
	}
	
	public function driveridcard()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('driveridcard');
		$crud->set_subject('Driver ID Card');
		$crud->columns('CardID', 'Driver', 'StartDate', 'EndDate', 'State');
		$crud->display_as('CardID', 'Card ID');
		$crud->display_as('Driver', 'Driver Name');
		$crud->display_as('StartDate', 'Start Date');
		$crud->display_as('EndDate', 'End Date');
		$crud->display_as('State', 'Card State');
		
		
	//	$crud->set_relation('Driver','driver','DriverName',array('State'=>'Valid'));
		$crud->set_relation('Driver','driver','DriverName');
		//$this->db->query("UPDATE driveridcard SET cardid=cardid+12, cardid=cardid+1");
		$crud->fields('Driver', 'StartDate', 'EndDate');
		//$crud->fields();
		$crud->required_fields('Driver', 'StartDate', 'EndDate');

		$crud->callback_add_field('State', function() {
			return '<input type="text" maxlength="60" value="Valid" name="State">';
			});
		
	//this->load->driver();
		$output = $crud->render();
		$this->Driveridcard_output($output);
	}

	function Driveridcard_output($output = null)
	{
		$this->load->view('driveridcard_view.php', $output);
	}
	
	public function supplier()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('supplier');
		$crud->set_subject('Supplier');
		$crud->columns('SupplierName', 'SupplierGaS', 'SupplierAddress', 'SupplierManager');
		$crud->display_as('Supplier ID');
		$crud->display_as('SupplierName','Supplier Name');
		$crud->display_as('SupplierGaS', 'Supplier Goods and Services');
		$crud->display_as('SupplierAddress', 'Supplier Address');
		$crud->display_as('SupplierManager', 'Supplier Manager');

		$crud->fields('SupplierName', 'SupplierGaS', 'SupplierAddress', 'SupplierManager');
		$crud->required_fields('SupplierName', 'SupplierGaS', 'SupplierAddress', 'SupplierManager');

		
		$output = $crud->render();
		$this->Supplier_output($output);
	}

	function Supplier_output($output = null)
	{
		$this->load->view('supplier_view.php', $output);
	}
	
}
